package com.tsu.android.chess.data

enum class Chessman {
    KING,
    QUEEN,
    BISHOP,
    ROOK,
    KNIGHT,
    PAWN,
}