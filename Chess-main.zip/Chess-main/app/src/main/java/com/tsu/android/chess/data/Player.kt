package com.tsu.android.chess.data

enum class Player {
    WHITE,
    BLACK,
}