package com.tsu.android.chess.data

data class Square(val col: Int, val row: Int)
